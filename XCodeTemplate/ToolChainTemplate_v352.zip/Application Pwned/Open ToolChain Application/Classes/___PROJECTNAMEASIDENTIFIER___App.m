//
//  ___PROJECTNAMEASIDENTIFIER___App.m
//  ___PROJECTNAME___
//

#import "___PROJECTNAMEASIDENTIFIER___App.h"

@implementation ___PROJECTNAMEASIDENTIFIER___App

@synthesize window;
@synthesize mainView;

- (void)applicationDidFinishLaunching:(UIApplication *)application {	
	// Create window
	window = [[UIWindow alloc] initWithContentRect: [UIHardware fullScreenApplicationContentRect]];
    
	// Set up content view
	mainView = [[UIView alloc] initWithFrame: [UIHardware fullScreenApplicationContentRect]];
	[window setContentView: mainView];
    
	// Show window
	[window makeKeyAndVisible];
}

- (void)dealloc {
	[mainView release];
	[window release];
	[super dealloc];
}

@end
