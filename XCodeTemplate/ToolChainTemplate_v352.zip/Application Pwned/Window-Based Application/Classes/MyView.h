//
//  MyView.h
//  ___PROJECTNAME___
//

#import <UIKit/UIKit.h>

@interface MyView : UIView {
}

@end
