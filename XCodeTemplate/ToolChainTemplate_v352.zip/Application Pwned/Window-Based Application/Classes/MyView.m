//
//  MyView.m
//  ___PROJECTNAME___
//

#import "MyView.h"

@implementation MyView

@end
