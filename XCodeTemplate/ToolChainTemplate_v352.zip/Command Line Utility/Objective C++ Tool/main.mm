#import <Foundation/Foundation.h>
#include <iostream>

int main (int argc, char * const argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    // insert code here...
    std::cout << "Hello, Objective C++ World!\n";
	NSLog(@"Hello");
	[pool drain];
    return 0;
}
