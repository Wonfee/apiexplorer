/*
 Static Library : lib�PROJECTNAME�.a
 �PROJECTNAME�.c
*/

// insert code here...
