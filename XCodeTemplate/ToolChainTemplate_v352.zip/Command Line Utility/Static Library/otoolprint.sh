#!/bin/sh
if [ -f lib�PROJECTNAME�.a ] ; then
  otool -t -v -arch arm lib�PROJECTNAME�.a
  otool -t -v -arch i386 lib�PROJECTNAME�.a
fi
if [ -f Debug-lib�PROJECTNAME�.a ] ; then
  otool -t -v -arch arm Debug-lib�PROJECTNAME�.a
  otool -t -v -arch i386 Debug-lib�PROJECTNAME�.a
fi
