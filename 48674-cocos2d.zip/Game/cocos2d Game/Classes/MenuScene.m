//
//  MenuScene.m
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#import "MenuScene.h"

@implementation MenuScene
- (id) init {
    self = [super init];
    if (self != nil) {
        Sprite * bg = [Sprite spriteWithFile:@"menu.png"];
        [bg setPosition:cpv(240, 160)];
        [self add:bg z:0];
        [self add:[MenuLayer node] z:1];
    }
    return self;
}
@end

@implementation MenuLayer
- (id) init {
    self = [super init];
    if (self != nil) {
        [MenuItemFont setFontSize:20];
        [MenuItemFont setFontName:@"Helvetica"];
        MenuItem *start = [MenuItemFont itemFromString:@"Start Game" target:self selector:@selector(startGame:)];
        MenuItem *help = [MenuItemFont itemFromString:@"Help" target:self selector:@selector(help:)];
		Menu *startMenu = [Menu menuWithItems:start, help, nil];
		[startMenu alignItemsVertically];
		[self add:startMenu];
    }
    return self;
}
-(void)startGame: (id)sender {
    NSLog(@"startGame");
}
-(void)help: (id)sender {
    NSLog(@"help");
}
@end
