//
//  ___PROJECTNAMEASIDENTIFIER___AppDelegate.m
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#import "___PROJECTNAMEASIDENTIFIER___AppDelegate.h"
#import "MenuScene.h"

@implementation ___PROJECTNAMEASIDENTIFIER___AppDelegate


-(void)applicationDidFinishLaunching:(UIApplication *)application {    
    // Game began...
    [[Director sharedDirector] setLandscape: YES];
//  optional for showing frame per sec
//  [[Director sharedDirector] setDisplayFPS:YES]; 
    MenuScene * ms = [MenuScene node];
    [[Director sharedDirector] runScene:ms];
}

-(void) applicationWillResignActive:(UIApplication *)application {
    // Incoming phone call...
    [[Director sharedDirector] pause];
}

-(void) applicationDidBecomeActive:(UIApplication *)application {
    // Phone call rejected...
    [[Director sharedDirector] resume];
}

-(void) applicationWillTerminate:(UIApplication*)application {
    // Application is ending...
    [[Director sharedDirector] release];
}

- (void)dealloc {
    [super dealloc];
}

@end
